export class Movie {
  id: number;
  title: string;
  director: string;
  description: string

  // constructor(public id: number) {}
}

import { Movie } from './movie';

export class Review {
  id: number;
  message: string;
  movie: Movie
}

import { City } from './city';

export class Cinema {
  id: number;
  name: string;
  address: string;
  countRooms: number;
  city: City
}

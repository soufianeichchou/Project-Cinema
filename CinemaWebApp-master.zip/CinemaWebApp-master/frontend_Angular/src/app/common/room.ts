import { Cinema } from './cinema';

export class Room {
  id: number;
  name: string;
  countSeats: number;
  cinema: Cinema;
}

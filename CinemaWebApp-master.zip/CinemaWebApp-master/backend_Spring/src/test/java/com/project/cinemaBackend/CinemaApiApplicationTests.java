package com.project.cinemaBackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CinemaApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
